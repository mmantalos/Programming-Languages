import java.util.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Stayhome {
	private static int N, M;

	private static Point start;
	private static Point goal;

	private static Deque<Virus> V;
	private static Deque<Point> S;
	private static Deque<Point> airports;

	private static int[] Obst;
	private static int[] Parent;

	private static boolean exists(int x, int y) {
		return x >= 0 && x < N && y >= 0 && y < M;
	}

	private static int locate(int x, int y) {
		return x*M + y;
	}

	private static void takeoff(int x0, int y0) {
		while(!airports.isEmpty()) {
			Point a = airports.poll();
			int x = a.getX(), y = a.getY();
			if (x != x0 || y != y0) {
				V.offer(new Virus(x, y, 7));
			}
		}
	}

	private static void spread() {
		int size = V.size();
		for (int i = 0; i < size; i++) { 
			Virus v = V.poll();
			int x = v.getX(), y = v.getY(), count = v.getCount();
			int xi, yi, t;
			count--;
			if (count == 2) {
				Obst[locate(x,y)] = 1;
			}
			if (count == 0) {
				int current = locate(x, y);

				xi = x+1; yi = y;
				t = locate(xi, yi);
				if (exists(xi, yi) && Obst[t] <= 0) {
					if (Obst[t] == -1 || Obst[t] == -3) {
						takeoff(xi, yi);
					}
					Obst[t] = 1;
					V.offer(new Virus(xi, yi, 2));
				}

				xi = x; yi = y-1;
				t = locate(xi, yi);
				if (exists(xi, yi) && Obst[t] <= 0) {
					if (Obst[t] == -1 || Obst[t] == -3) {
						takeoff(xi, yi);
					}
					Obst[t] = 1;
					V.offer(new Virus(xi, yi, 2));
				}

				xi = x; yi = y+1;
				t = locate(xi, yi);
				if (exists(xi, yi) && Obst[t] <= 0) {
					if (Obst[t] == -1 || Obst[t] == -3) {
						takeoff(xi, yi);
					}
					Obst[t] = 1;
					V.offer(new Virus(xi, yi, 2));
				}

				xi = x-1; yi = y;
				t = locate(xi, yi);
				if (exists(xi, yi) && Obst[t] <= 0) {
					if (Obst[t] == -1 || Obst[t] == -3) {
						takeoff(xi, yi);
					}
					Obst[t] = 1;
					V.offer(new Virus(xi, yi, 2));
				}
			}
			else V.offer(new Virus(x, y, count));
		}
	}

	private static void move() {
		int size = S.size();
		for(int i = 0; i < size; i++){
			Point s = S.poll();
			int x = s.getX(), y = s.getY(), xi, yi, t;
			int current = locate(x, y);

			xi = x+1; yi = y;
			t = locate(xi, yi);
			if (exists(xi, yi) && (Obst[t] == 0 || Obst[t] == -1)) {
				Obst[t] -= 2;
				Parent[t] = current;
				S.offer(new Point(xi, yi));
			}
			
			xi = x; yi = y-1;
			t = locate(xi, yi);
			if (exists(xi, yi) && (Obst[t] == 0 || Obst[t] == -1)) {
				Obst[t] -= 2;
				Parent[t] = current;
				S.offer(new Point(xi, yi));
			}
			
			xi = x; yi = y+1;
			t = locate(xi, yi);
			if (exists(xi, yi) && (Obst[t] == 0 || Obst[t] == -1)) {
				Obst[t] -= 2;
				Parent[t] = current;
				S.offer(new Point(xi, yi));
			}
			
			xi = x-1; yi = y;
			t = locate(xi, yi);
			if (exists(xi, yi) && (Obst[t] == 0 || Obst[t] == -1)) {
				Obst[t] -= 2;
				Parent[t] = current;
				S.offer(new Point(xi, yi));
			}
		}
	}

	private static String path() {
		String path = "";
		int x = goal.getX(), y = goal.getY();
		int current = locate(x,y), prev;
		while (Parent[current] >= 0) {
			prev = Parent[current];

			if      (prev == (current + 1)) path = "L".concat(path);
			else if (prev == (current - 1)) path = "R".concat(path);	
			else if (prev == (current + M)) path = "U".concat(path);	
			else if (prev == (current - M)) path = "D".concat(path);

			current = prev; 	
		}
		return path;
	}

	public static void main(String[] args) throws IOException {
		V = new ArrayDeque<Virus>();
		S = new ArrayDeque<Point>();
		airports = new ArrayDeque<Point>();

		// Reading from file was created based on code from this website:
		// https://www.candidjava.com/tutorial/program-to-read-a-file-character-by-character/

		File myFile = new File(args[0]);
		FileReader myReader = new FileReader(myFile);
		BufferedReader myBuffer = new BufferedReader(myReader);

		int c = 0, n = 0, i = 0;
		Deque<Integer> ob = new ArrayDeque<Integer>();
		while((c = myBuffer.read()) != -1) {
			char temp = (char) c;
			if (temp == '.') {
				ob.offer(0);
			}
			else if (temp == 'X') {
				ob.offer(1);
			}
			else if (temp == 'A') {
				ob.offer(-1);
				airports.offer(new Point(n, i));
			}
			else if (temp == 'W') {
				ob.offer(1);
				V.offer(new Virus(n, i, 2));
			}
			else if (temp == 'S') {
				ob.offer(-2);
				S.offer(new Point(n, i));
				start = new Point(n, i);
			}
			else if (temp == 'T') {
				ob.offer(0);
				goal = new Point(n, i);
			}
			else {
				n++;
				i = 0;
				continue;
			}
			i++;
		}
		N  = n;
		M = ob.size() / n;

		Obst = new int[N*M];
		Parent = new int[N*M];

		i = 0;
		while(!ob.isEmpty()) {
			Obst[i] = ob.poll();
			Parent[i++] = -1;
		}
		
		int goalx = goal.getX(), goaly = goal.getY();
		int end = locate(goalx, goaly);		
		while (Obst[end] == 0 && S.size() > 0) {
			spread();
			move();
		}
		if (Parent[end] < 0) {
			System.out.println("IMPOSSIBLE");
		}
		else {
			String p = path();
			System.out.println(p.length());
			System.out.println(p);
		}
	}
}

