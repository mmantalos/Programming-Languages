public class Virus {
	private int X, Y, Count;

	public Virus(int x, int y, int c) {
		X = x;
		Y = y;
		Count = c;
	}

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public int getCount() {
		return Count;
	}

	public static void main() {
	}

}
