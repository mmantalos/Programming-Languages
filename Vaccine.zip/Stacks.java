import java.util.*;

public class Stacks {
	public int Length; 
	public char S0, First, Last;
	public boolean U, A, C, G;

	public Stacks(int len, char s0, char f, char l, Boolean u, Boolean a, Boolean c, Boolean g) {
		Length = len;
		S0 = s0;
		First = f;
		Last = l;
		U = u;
		A = a;
		C = c;
		G = g;
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Stacks other = (Stacks) o;
		return Length == other.Length && S0 == other.S0 && First == other.First 
			&& Last == other.Last && U == other.U && A == other.A 
			&& C == other.C && G == other.G;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Length, S0, First, Last, U, A, C, G);
	}
}
