import java.util.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Vaccine {
	private static String S;
	private static int End;
	private static Deque<String> Vac;
	private static Deque<Integer> Top;
	private static Deque<Character> First, Last;
	private static Deque<Boolean> Comp, ContainsU, ContainsA, ContainsC, ContainsG;

	private static String reverse(String s) {
		char[] temp = s.toCharArray();
		String reverse = "";
		int size = s.length();
		for (int i = size - 1; i >= 0; i--) {
			reverse += temp[i];
		}	
		return reverse;

	}

	private static char complement(char c) {
		if (c == 'U') return 'A';
		if (c == 'A') return 'U';
		if (c == 'C') return 'G';
		if (c == 'G') return 'C';
		return 'E';

	}

	private static String solve() {
		Set<Stacks> seen = new HashSet<>();
		String vac;
		int top;
		char s1_0, first, last;
		Boolean comp, U, A, C, G;

		while(true){
			vac = Vac.poll();
			top = Top.poll();
			first = First.poll();
			last = Last.poll();
			comp = Comp.poll();
			U = ContainsU.poll(); 
			A = ContainsA.poll(); 
			C = ContainsC.poll(); 
			G = ContainsG.poll();
			
			if (comp) s1_0 = complement(S.charAt(top));
			else s1_0 = S.charAt(top);

			Stacks state = new Stacks(End - top, s1_0, first, last, U, A, C, G);
			if (!seen.contains(state)){
				seen.add(state);			

				if (vac.charAt(vac.length()-1) == 'p') {
					Vac.offer(vac + "c");
					Top.offer(top);
					First.offer(first);
					Last.offer(last);
					Comp.offer(!comp);
					ContainsU.offer(U);
					ContainsA.offer(A);
					ContainsC.offer(C);
					ContainsG.offer(G);
				}

				if ((s1_0 == first) || ((s1_0 == 'U') && !U) || ((s1_0 == 'A') && !A)
						|| ((s1_0 == 'C') && !C) || ((s1_0 == 'G') && !G)) {

					String vac_new = vac + "p";

					Vac.offer(vac_new);
					Top.offer(top + 1);
					First.offer(s1_0);
					Last.offer(last);
					Comp.offer(comp);
					ContainsU.offer(U || (s1_0 == 'U'));
					ContainsA.offer(A || (s1_0 == 'A'));
					ContainsC.offer(C || (s1_0 == 'C'));
					ContainsG.offer(G || (s1_0 == 'G'));

					if (top + 1 == End) return vac_new;
						}

				if(vac.charAt(vac.length()-1) != 'r'){
					Vac.offer(vac + "r");
					Top.offer(top);
					First.offer(last);
					Last.offer(first);
					Comp.offer(comp);
					ContainsU.offer(U);
					ContainsA.offer(A);
					ContainsC.offer(C);
					ContainsG.offer(G);
				}
			}	
		}
	}	

	public static void main(String[] args) throws IOException {

		int N;

		// Reading from file was created based on code from this website:
		// https://www.candidjava.com/tutorial/program-to-read-a-file-character-by-character/

		File myFile = new File(args[0]);
		FileReader myReader = new FileReader(myFile);
		BufferedReader myBuffer = new BufferedReader(myReader);

		N = myBuffer.read() - 48;
		if (myBuffer.read() != '\n') {
			N = 10;
			myBuffer.read();
		}

		while(N-- != 0) {
			Vac = new ArrayDeque<String>();
			Top = new ArrayDeque<Integer>();
			First = new ArrayDeque<Character>();
			Last = new ArrayDeque<Character>();
			Comp = new ArrayDeque<Boolean>();
			ContainsU = new ArrayDeque<Boolean>();
			ContainsA = new ArrayDeque<Boolean>();
			ContainsC = new ArrayDeque<Boolean>();
			ContainsG = new ArrayDeque<Boolean>();

			S = reverse(myBuffer.readLine());
			End = S.length();

			Vac.offer("p");

			Top.offer(1);

			First.offer(S.charAt(0));
			Last.offer(S.charAt(0));

			Comp.offer(false);

			ContainsU.offer(S.charAt(0) == 'U');
			ContainsA.offer(S.charAt(0) == 'A');
			ContainsC.offer(S.charAt(0) == 'C');
			ContainsG.offer(S.charAt(0) == 'G');

			System.out.println(solve());
		}
	}
}

